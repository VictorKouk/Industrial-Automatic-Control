�
Language0�Language1
     M5 START�     M5 START
     M2 START�     M2 START
     M4 START�     M4 START
     M1 START�     M1 START
     M7 START�     M7 START
     M8 START�     M8 START
     M3 START�     M3 START
     M9 START�     M9 START
           GENERAL START�           GENERAL START
     M6 START�     M6 START
           GENERAL STOP�           GENERAL STOP
     M1 STOP�     M1 STOP
     M3 STOP�     M3 STOP
     M2 STOP�     M2 STOP
     M4 STOP�     M4 STOP
     M7 STOP�     M7 STOP
     M5 STOP�     M5 STOP
     M8 STOP�     M8 STOP
      M6 STOP�      M6 STOP
     M9 STOP �     M9 STOP 
             ROTATION OF M7�             ROTATION OF M7
     LEFT                         RIGHT�     LEFT                         RIGHT
Active�Active
Ack�Ack
Message�Message
Date�Date
Time�Time
Class 1�Class 1
Class 2�Class 2
To ack�To ack
Excluded�Excluded
Exit Button�Exit Button
Exit Runtime�Exit Runtime
Ergasia BAE�Ergasia BAE
